# Northstar Advisory — Kagona Web Design portfolio concept

A responsive, single-page HTML/CSS/JavaScript demo for a fictional professional-services firm covering accounting, audit, and business advisory.

## Files
- `index.html` — page structure and content
- `styles.css` — visual design, layout, and responsive styling
- `script.js` — mobile navigation, scroll reveals, service preselection, and demo-form validation

## Run it
Keep all three source files in the same folder and open `index.html` in a browser, or publish the folder with GitHub Pages.

## Before using for a real client
- Replace all concept imagery with licensed/approved images.
- Replace fictional brand name, service descriptions, and contact details with client-approved content.
- Connect the consultation form to a real, approved inbox or enquiry service. The current form only validates in the browser and does not transmit or store submissions.
- Verify all claims, services, professional qualifications, and regulatory language with the real firm.
- Check mobile and desktop layouts after publishing. Google Fonts and the remote Unsplash images require an internet connection.

This is a fictional portfolio concept. It does not represent a real accounting, audit, or advisory firm.
